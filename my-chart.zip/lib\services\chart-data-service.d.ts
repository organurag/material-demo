import { ChartData } from '../models/Chart-data-model';
import * as i0 from "@angular/core";
export declare abstract class ChartDataService {
    /**
     * Abstract method to fetch data from an API or other sources.
     * Must be implemented by the subclass.
     */
    abstract fetchData(): Promise<any[]>;
    /**
     * Processes raw data fetched from the source into a structured format.
     * This method can be called internally or overridden if specific data processing is required.
     *
     * @param data Raw data array fetched from the source.
     * @returns Processed data structured as ChartData.
     */
    protected processData(data: any[]): ChartData;
    /**
     * Loads data by calling fetchData and then processing it.
     * Returns the processed data in the ChartData format.
     *
     * @returns Promise that resolves to ChartData.
     */
    loadData(): Promise<ChartData>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChartDataService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ChartDataService>;
}
