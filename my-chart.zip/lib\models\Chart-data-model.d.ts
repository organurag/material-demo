export interface ChartDataset {
    label: string;
    data: number[];
    backgroundColor: string;
    borderColor: string;
}
export interface ChartData {
    labels: string[];
    datasets: ChartDataset[];
}
