import { OnInit } from '@angular/core';
import { Chart } from 'chart.js';
import { ChartDataService } from './services/chart-data-service';
import * as i0 from "@angular/core";
export declare class MyChartComponent implements OnInit {
    private chartDataService;
    canvasId: string;
    chart: Chart | undefined;
    constructor(chartDataService: ChartDataService);
    ngOnInit(): void;
    private loadChartData;
    private createChart;
    static ɵfac: i0.ɵɵFactoryDeclaration<MyChartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MyChartComponent, "lib-my-chart", never, {}, {}, never, never, false, never>;
}
