import * as i0 from '@angular/core';
import { Injectable, Component, NgModule } from '@angular/core';
import { Chart, registerables } from 'chart.js';
import { MatButtonModule } from '@angular/material/button';

class MyChartService {
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.1.2", ngImport: i0, type: MyChartService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.1.2", ngImport: i0, type: MyChartService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.1.2", ngImport: i0, type: MyChartService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [] });

class ChartDataService {
    /**
     * Processes raw data fetched from the source into a structured format.
     * This method can be called internally or overridden if specific data processing is required.
     *
     * @param data Raw data array fetched from the source.
     * @returns Processed data structured as ChartData.
     */
    processData(data) {
        if (data && data.length > 0) {
            const apiData = data[0];
            const transformedData = {
                labels: apiData.labels || [],
                datasets: apiData.datasets.map((dataset) => ({
                    label: dataset.label || '',
                    data: dataset.data || [],
                    backgroundColor: dataset.backgroundColor || 'transparent',
                    borderColor: dataset.borderColor || 'black',
                }))
            };
            return transformedData;
        }
        else {
            throw new Error('Received empty or invalid data');
        }
    }
    /**
     * Loads data by calling fetchData and then processing it.
     * Returns the processed data in the ChartData format.
     *
     * @returns Promise that resolves to ChartData.
     */
    async loadData() {
        const rawData = await this.fetchData();
        console.log(this.processData(rawData));
        return this.processData(rawData);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.1.2", ngImport: i0, type: ChartDataService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.1.2", ngImport: i0, type: ChartDataService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.1.2", ngImport: i0, type: ChartDataService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class MyChartComponent {
    constructor(chartDataService) {
        this.chartDataService = chartDataService;
        Chart.register(...registerables);
    }
    ngOnInit() {
        this.loadChartData();
    }
    loadChartData() {
        this.chartDataService.loadData().then((data) => {
            this.createChart(data);
        });
    }
    createChart(data) {
        if (this.chart) {
            this.chart.destroy();
        }
        const canvas = document.getElementById('MyChart');
        if (canvas) {
            const ctx = canvas.getContext('2d');
            if (ctx) {
                this.chart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: data.labels,
                        datasets: data.datasets,
                    },
                    options: {
                        aspectRatio: 2,
                        plugins: {
                            colors: {
                                forceOverride: true
                            },
                            title: {
                                display: true,
                                text: 'Weekly Data',
                                font: {
                                    size: 20
                                },
                                position: 'top'
                            },
                            legend: {
                                labels: {
                                    font: {
                                        size: 14,
                                    },
                                },
                            },
                        },
                    },
                });
            }
            else {
                console.error('Failed to get 2D context from canvas element');
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.1.2", ngImport: i0, type: MyChartComponent, deps: [{ token: ChartDataService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.1.2", type: MyChartComponent, selector: "lib-my-chart", ngImport: i0, template: `
    <div class="chart-container">
      <canvas id="MyChart"></canvas>
    </div>
  `, isInline: true, styles: [".chart-container{margin:10px;padding:10px}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.1.2", ngImport: i0, type: MyChartComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-my-chart', template: `
    <div class="chart-container">
      <canvas id="MyChart"></canvas>
    </div>
  `, styles: [".chart-container{margin:10px;padding:10px}\n"] }]
        }], ctorParameters: () => [{ type: ChartDataService }] });

class MyChartModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.1.2", ngImport: i0, type: MyChartModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "18.1.2", ngImport: i0, type: MyChartModule, bootstrap: [MyChartComponent], declarations: [MyChartComponent], imports: [MatButtonModule], exports: [MyChartComponent, MatButtonModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "18.1.2", ngImport: i0, type: MyChartModule, imports: [MatButtonModule, MatButtonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.1.2", ngImport: i0, type: MyChartModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [MyChartComponent],
                    imports: [MatButtonModule],
                    exports: [MyChartComponent, MatButtonModule],
                    bootstrap: [MyChartComponent]
                }]
        }] });

/*
 * Public API Surface of my-chart
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ChartDataService, MyChartComponent, MyChartModule, MyChartService };
//# sourceMappingURL=my-chart.mjs.map
