import * as i0 from "@angular/core";
import * as i1 from "./my-chart.component";
import * as i2 from "@angular/material/button";
export declare class MyChartModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MyChartModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MyChartModule, [typeof i1.MyChartComponent], [typeof i2.MatButtonModule], [typeof i1.MyChartComponent, typeof i2.MatButtonModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MyChartModule>;
}
